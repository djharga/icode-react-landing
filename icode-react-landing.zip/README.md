# ICODE Landing (React + Vite)

## تشغيل محلي
1) ثبت Node.js (LTS)
2) داخل المجلد:
   npm install
   npm run dev

## بناء للنشر
npm run build
المخرجات داخل dist/

## تعديل واتساب
افتح src/App.jsx وعدّل:
WHATSAPP_E164 = "+201234567890"
